<?php
const CONF_DB_HOST = "mysql";
const CONF_DB_USER = "root";
const CONF_DB_PASS = "asdf1234";
const CONF_DB_NAME = "db-inf-3am"; // aqui deve ser alterado para o nome do banco de dados
const CONF_URL_TEST = "http://localhost/Agenda-rapido";
const CONF_URL_BASE = "http://localhost/Agenda-rapido";