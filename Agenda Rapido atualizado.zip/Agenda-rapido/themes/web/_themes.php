<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Agenda Rapido</title>
</head>
<body>
     <section>
        <div class="circle"></div>
        <header>
            <a href="#"><img src="./assets/css/assets/Pedro_rocha__3_-removebg-preview.png" alt="" class="logo"></a>
            <nav class="navegation">
                <ul>
                    <li><a href="<?= url();?>">Home</a></li>
                    <li><a href="<?= url("sobre");?>">Sobre</a></li>
                    <li><a href="<?= url("servicos");?>">Serviços</a></li>
                    <li><a href="<?= url("registro");?>">Vire membro</a></li>
                    <li><a href="<?= url("login");?>">Ja sou membro</a></li>
                </ul>
            </nav>
            
        </header> 
        <?php
    echo $this->section("content");
    ?>  
    </section>

    

</body>
</html>