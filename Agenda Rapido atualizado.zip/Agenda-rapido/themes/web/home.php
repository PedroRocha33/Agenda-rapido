<?php
    $this->layout("_themes");
?>
<link rel="stylesheet" href="./assets/css/style.css"> 
 <div class="content">
            <div class="text">
                <h2>AGENDA <br><span>Online</span></h2>
                <p>Ela serve para organizar os seus agendamentos em só lugar! Desta forma, você e os seus profissionais conseguem visualizar todos os serviços que serão feitos no mês e quais os clientes que serão atendidos. E o melhor, ela sendo online, você consegue controlar todo o fluxo de atendimentos em qualquer momento e em qualquer lugar.</p>
                <a href="<?= url("servicos");?>">Serviços</a>
            </div>
        </div>
        