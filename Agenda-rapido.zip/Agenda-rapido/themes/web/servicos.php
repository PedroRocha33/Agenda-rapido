<?php
    $this->layout("_themes");
?>
<link rel="stylesheet" href="./assets/css/style.css"> 
        <div class="content">
            <div class="text">
                <main>
                    <div class="service" >
                        <div class="service-cont">
                            <h2>Mensal:</h2>
                            <h3 class="price">100.00 R$</h3>
                            <h4>100 R$ p mes</h4>
                            <br>
                            <button>Adquirir</button>

                        </div>
                    </div>
                <div class="service">
                        <div class="service-cont">
                            <h2>Trimestral:</h2>
                            <h3 class="price">270.00 R$</h3>
                            <h4>90 R$ p/ mes</h4>
                            <br>
                            <button>Adquirir</button>
                        </div>
                    </div>
                    <div class="service" >
                        <div class="service-cont">
                            <h2>Semestral:</h2>
                            <h3 class="price">500.00 R$</h3>
                            <h4>84 $ p/ mes</h4>
                            <br>
                            <button>Adquirir</button>

                        </div>
                    </div>
                </main>
            </div>
        </div>
        
    </section>
</body>
</html>
