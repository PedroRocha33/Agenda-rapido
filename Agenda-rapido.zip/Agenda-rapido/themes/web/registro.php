<?php
    $this->layout("_themes");
?>

<link rel="stylesheet" href="./assets/css/registro.css"> 
    <section>
        <div class="container">
    <div class="box register-form">
        <h2>Registro</h2>
        <form action="#">
            <input type="text" placeholder="Nome de usuário">
            <input type="password" placeholder="Senha">
            <input type="password" placeholder="Confirmar Senha">
            <input type="submit" value="Registrar">
        </form>
    </div>
    
</div>
    </section>
</body>
</html>
