<?php
    $this->layout("_themes");
?>
<link rel="stylesheet" href="./assets/css/style.css"> 
        <div class="content">
            <div class="text">
                <h2>SOBRE</h2>
                <p>Ela serve para organizar os seus agendamentos em só lugar! Desta forma, você e os seus profissionais conseguem visualizar todos os serviços que serão feitos no mês e quais os clientes que serão atendidos. E o melhor, ela sendo online, você consegue controlar todo o fluxo de atendimentos em qualquer momento e em qualquer lugar.</p>
                
                <h2>Agendamentos</h2>
                <p>Controle dos seus agendamentos: A falta de organização pode te fazer perder clientes! Imagina você anotar um agendamento no papel e perder?
                Com uma agenda online é possível sempre dar uma olhadinha nos serviços do dia, a qualquer momento e em qualquer lugar. Isso vai evitar que você e os seus profissionais esqueçam dos horários. </p>
                
                <h2>Tempo</h2>
                <p>Seus clientes não ficam esperando: Sabemos que ninguém gosta de esperar, né?

                    Por isso, o agendamento online traz a facilidade do cliente definir o horário que vai realizar o serviço escolhido</p>
                <br>
                    <hr>
                <h2>Contato</h2>
                <p>para contatar, clque no botão abaixo.</p>
                <a href="<?= url("sobre");?>">Clique aqui</a>
            </div>
        </div>
        
    </section>

